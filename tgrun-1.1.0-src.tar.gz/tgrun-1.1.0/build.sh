#!/usr/bin/env sh
set -eu

VERSION=1.1.0
mkdir -p dist

CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build \
  -buildvcs=false -trimpath -ldflags="-s -w" -o dist/tgrun-linux-amd64 .

CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build \
  -buildvcs=false -trimpath -ldflags="-s -w" -o dist/tgrun-linux-arm64 .

(
  cd dist
  sha256sum tgrun-linux-amd64 tgrun-linux-arm64 > SHA256SUMS.binaries
)

printf 'Built tgrun %s\n' "$VERSION"
