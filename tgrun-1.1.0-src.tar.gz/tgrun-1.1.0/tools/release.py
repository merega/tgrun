#!/usr/bin/env python3
"""Build the complete tgrun release without architecture-specific packagers."""

from __future__ import annotations

import gzip
import hashlib
import io
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

VERSION = "1.1.0"
DEB_VERSION = f"{VERSION}-1"
ARCHITECTURES = ("amd64", "arm64")
ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
GO = os.environ.get("GO", "go")
os.environ.setdefault("GOCACHE", str(ROOT / "work" / "go-build"))
os.environ.setdefault("GOPATH", str(ROOT / "work" / "gopath"))


def run(args: list[str], *, env: dict[str, str] | None = None) -> None:
    print("+", " ".join(args))
    subprocess.run(args, cwd=ROOT, env=env, check=True)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tar_info(name: str, mode: int, size: int = 0, *, directory: bool = False) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name)
    info.mode = mode
    info.uid = 0
    info.gid = 0
    info.uname = "root"
    info.gname = "root"
    info.mtime = 0
    info.size = size
    if directory:
        info.type = tarfile.DIRTYPE
    return info


def gzipped(data: bytes) -> bytes:
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as stream:
        stream.write(data)
    return output.getvalue()


def tar_gz(entries: list[tuple[str, bytes | None, int]]) -> bytes:
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.GNU_FORMAT) as archive:
        for name, data, mode in entries:
            if data is None:
                archive.addfile(tar_info(name, mode, directory=True))
            else:
                archive.addfile(tar_info(name, mode, len(data)), io.BytesIO(data))
    return gzipped(raw.getvalue())


def ar_member(name: str, data: bytes) -> bytes:
    encoded_name = (name + "/").encode("ascii")
    header = (
        encoded_name.ljust(16)
        + b"0".ljust(12)
        + b"0".ljust(6)
        + b"0".ljust(6)
        + b"100644".ljust(8)
        + str(len(data)).encode("ascii").ljust(10)
        + b"`\n"
    )
    return header + data + (b"\n" if len(data) % 2 else b"")


def gzip_file(path: Path) -> bytes:
    return gzipped(path.read_bytes())


def build_deb(arch: str, binary: Path) -> Path:
    readme = ROOT.joinpath("README.md").read_bytes()
    copyright_text = ROOT.joinpath("debian", "copyright").read_bytes()
    changelog = gzip_file(ROOT / "debian" / "changelog")
    manpage = gzip_file(ROOT / "tgrun.1")
    config = ROOT.joinpath("tgrun.conf.example").read_bytes()
    installed_size = (len(binary.read_bytes()) + len(readme) + len(config) + 1023) // 1024

    control = f"""Package: tgrun
Version: {DEB_VERSION}
Section: admin
Priority: optional
Architecture: {arch}
Maintainer: tgrun maintainers <maintainers@example.invalid>
Installed-Size: {installed_size}
Description: run commands and send completion notifications to Telegram
 tgrun runs a command, preserves its exit status and sends the result,
 duration and optionally the last output lines to a Telegram chat.
""".encode()
    control_tar = tar_gz(
        [
            ("./control", control, 0o644),
            ("./conffiles", b"/etc/tgrun.conf\n", 0o644),
        ]
    )
    data_tar = tar_gz(
        [
            ("./usr/", None, 0o755),
            ("./usr/bin/", None, 0o755),
            ("./usr/bin/tgrun", binary.read_bytes(), 0o755),
            ("./usr/share/", None, 0o755),
            ("./usr/share/doc/", None, 0o755),
            ("./usr/share/doc/tgrun/", None, 0o755),
            ("./usr/share/doc/tgrun/README.md", readme, 0o644),
            ("./usr/share/doc/tgrun/changelog.Debian.gz", changelog, 0o644),
            ("./usr/share/doc/tgrun/copyright", copyright_text, 0o644),
            ("./usr/share/man/", None, 0o755),
            ("./usr/share/man/man1/", None, 0o755),
            ("./usr/share/man/man1/tgrun.1.gz", manpage, 0o644),
            ("./etc/", None, 0o755),
            ("./etc/tgrun.conf", config, 0o600),
        ]
    )
    destination = DIST / f"tgrun_{VERSION}_{arch}.deb"
    destination.write_bytes(
        b"!<arch>\n"
        + ar_member("debian-binary", b"2.0\n")
        + ar_member("control.tar.gz", control_tar)
        + ar_member("data.tar.gz", data_tar)
    )
    return destination


def source_files() -> list[Path]:
    excluded_top = {"dist", "work", ".git"}
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT)
        if relative.parts[0] in excluded_top or "__pycache__" in relative.parts:
            continue
        if path.is_file():
            files.append(relative)
    return sorted(files, key=lambda item: item.as_posix())


def create_archive(destination: Path, members: list[tuple[Path, str, int]]) -> None:
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.GNU_FORMAT) as archive:
        for source, name, mode in members:
            data = source.read_bytes()
            archive.addfile(tar_info(name, mode, len(data)), io.BytesIO(data))
    destination.write_bytes(gzipped(raw.getvalue()))


def mode_for(path: Path) -> int:
    return 0o755 if path.name in {"build.sh", "install.sh", "release.sh", "rules", "release.py"} else 0o644


def main() -> int:
    DIST.mkdir(exist_ok=True)
    for old in DIST.iterdir():
        if old.is_dir():
            shutil.rmtree(old)
        else:
            old.unlink()

    gofmt = str(Path(GO).with_name("gofmt")) if Path(GO).name.lower().startswith("go") else "gofmt"
    if os.name == "nt" and not gofmt.lower().endswith(".exe"):
        gofmt += ".exe"
    run([gofmt, "-w", "main.go", "main_test.go"])
    run([GO, "test", "./..."])
    run([GO, "vet", "./..."])

    with tempfile.TemporaryDirectory() as temp:
        suffix = ".exe" if os.name == "nt" else ""
        cli = Path(temp) / f"tgrun{suffix}"
        run([GO, "build", "-buildvcs=false", "-trimpath", "-o", str(cli), "."])
        output = subprocess.check_output([str(cli), "version"], text=True).strip()
        if output != f"tgrun {VERSION}":
            raise RuntimeError(f"unexpected CLI version: {output}")
        subprocess.run([str(cli), "--help"], check=True, stdout=subprocess.DEVNULL)
        no_args = subprocess.run([str(cli)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if no_args.returncode != 2:
            raise RuntimeError(f"no-argument exit code is {no_args.returncode}, expected 2")

    binaries: dict[str, Path] = {}
    for arch in ARCHITECTURES:
        destination = DIST / f"tgrun-linux-{arch}"
        env = os.environ.copy()
        env.update({"CGO_ENABLED": "0", "GOOS": "linux", "GOARCH": arch})
        run(
            [
                GO,
                "build",
                "-buildvcs=false",
                "-trimpath",
                "-ldflags=-s -w",
                "-o",
                str(destination),
                ".",
            ],
            env=env,
        )
        binaries[arch] = destination

    packages = [build_deb(arch, binaries[arch]) for arch in ARCHITECTURES]

    source_archive = DIST / f"tgrun-{VERSION}-src.tar.gz"
    create_archive(
        source_archive,
        [
            (ROOT / path, f"tgrun-{VERSION}/{path.as_posix()}", mode_for(path))
            for path in source_files()
        ],
    )

    public_files = [
        binaries["amd64"],
        binaries["arm64"],
        *packages,
        source_archive,
    ]
    copied = [
        (ROOT / "README.md", DIST / "README.md"),
        (ROOT / "CHANGELOG.md", DIST / "CHANGELOG.md"),
        (ROOT / "install.sh", DIST / "install.sh"),
        (ROOT / "tgrun.conf.example", DIST / "tgrun.conf.example"),
    ]
    for source, destination in copied:
        shutil.copyfile(source, destination)
        public_files.append(destination)

    checksums = "".join(f"{sha256(path)}  {path.name}\n" for path in public_files)
    checksum_path = DIST / "SHA256SUMS"
    checksum_path.write_text(checksums, encoding="utf-8", newline="\n")

    bundle_files = public_files + [checksum_path]
    bundle = DIST / f"tgrun-{VERSION}-release.tar.gz"
    create_archive(
        bundle,
        [
            (
                path,
                f"tgrun-{VERSION}/{path.name}",
                0o755 if path.name in {"install.sh", "tgrun-linux-amd64", "tgrun-linux-arm64"} else 0o644,
            )
            for path in bundle_files
        ],
    )
    print(f"Release ready: {bundle}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
