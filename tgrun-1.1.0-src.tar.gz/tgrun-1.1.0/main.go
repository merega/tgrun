package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/user"
	"strconv"
	"strings"
	"time"
)

const (
	version           = "1.1.0"
	defaultConfigPath = "/etc/tgrun.conf"
	maxTelegramText   = 3900
)

type config struct {
	BotToken          string
	ChatID            string
	ThreadID          string
	SendOutput        string
	OutputLines       int
	HTTPTimeoutSecond int
}

type telegramResponse struct {
	OK          bool            `json:"ok"`
	Description string          `json:"description"`
	Result      json.RawMessage `json:"result"`
}

type updatesResult struct {
	UpdateID      int64    `json:"update_id"`
	Message       *message `json:"message"`
	EditedMessage *message `json:"edited_message"`
	ChannelPost   *message `json:"channel_post"`
	EditedPost    *message `json:"edited_channel_post"`
}

type message struct {
	Chat            chat  `json:"chat"`
	MessageThreadID int64 `json:"message_thread_id"`
}

type chat struct {
	ID        int64  `json:"id"`
	Type      string `json:"type"`
	Title     string `json:"title"`
	Username  string `json:"username"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
}

type foundChat struct {
	Type     string
	Name     string
	ChatID   int64
	ThreadID int64
}

func defaultConfig() config {
	return config{
		SendOutput:        "on-error",
		OutputLines:       20,
		HTTPTimeoutSecond: 15,
	}
}

func main() {
	os.Exit(runCLI(os.Args[1:]))
}

func runCLI(args []string) int {
	configPath := defaultConfigPath
	for len(args) >= 2 && args[0] == "--config" {
		configPath = args[1]
		args = args[2:]
	}

	if len(args) == 0 {
		showHelp(os.Stderr)
		return 2
	}

	switch args[0] {
	case "help", "--help", "-h":
		showHelp(os.Stdout)
		return 0
	case "version", "--version", "-v":
		fmt.Printf("tgrun %s\n", version)
		return 0
	}

	cfg, err := loadConfig(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "tgrun: configuration error: %v\n", err)
		return 2
	}

	switch args[0] {
	case "get-chat-id":
		if err := getChatIDs(cfg, os.Stdout); err != nil {
			fmt.Fprintf(os.Stderr, "tgrun: get-chat-id: %v\n", err)
			return 1
		}
		return 0
	case "notify":
		if len(args) < 2 {
			fmt.Fprintln(os.Stderr, "tgrun: notify requires a message")
			return 2
		}
		if err := sendPlainNotification(cfg, strings.Join(args[1:], " ")); err != nil {
			fmt.Fprintf(os.Stderr, "tgrun: notification failed: %v\n", err)
			return 1
		}
		return 0
	case "test":
		if err := sendPlainNotification(cfg, "Тестовое уведомление от tgrun"); err != nil {
			fmt.Fprintf(os.Stderr, "tgrun: test failed: %v\n", err)
			return 1
		}
		fmt.Println("Тестовое уведомление отправлено")
		return 0
	case "run":
		args = args[1:]
		if len(args) == 0 {
			fmt.Fprintln(os.Stderr, "tgrun: run requires a command")
			return 2
		}
	}

	return runCommand(cfg, args)
}

func showHelp(w io.Writer) {
	fmt.Fprintf(w, `tgrun %s — запуск команд с уведомлением в Telegram

Использование:
  tgrun [--config FILE] COMMAND [ARG...]
  tgrun [--config FILE] run COMMAND [ARG...]
  tgrun [--config FILE] notify TEXT
  tgrun [--config FILE] test
  tgrun [--config FILE] get-chat-id
  tgrun version

Команды:
  get-chat-id  Показать чаты из Telegram Bot API getUpdates
  notify       Отправить произвольное сообщение
  test         Отправить тестовое уведомление
  version      Показать версию
  help         Показать эту справку

Примеры:
  tgrun sleep 10
  tgrun bash -lc 'mysqldump mydb | gzip > /backup/mydb.sql.gz'
  tgrun get-chat-id
`, version)
}

func loadConfig(path string) (config, error) {
	cfg := defaultConfig()
	f, err := os.Open(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return cfg, fmt.Errorf("%s not found", path)
		}
		return cfg, err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	lineNo := 0
	for scanner.Scan() {
		lineNo++
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
			continue
		}
		key, value, ok := strings.Cut(line, "=")
		if !ok {
			return cfg, fmt.Errorf("%s:%d: expected key=value", path, lineNo)
		}
		key = strings.TrimSpace(key)
		value = strings.Trim(strings.TrimSpace(value), `"'`)
		switch key {
		case "bot_token":
			cfg.BotToken = value
		case "chat_id":
			cfg.ChatID = value
		case "thread_id":
			cfg.ThreadID = value
		case "send_output":
			cfg.SendOutput = value
		case "output_lines":
			n, convErr := strconv.Atoi(value)
			if convErr != nil || n < 0 {
				return cfg, fmt.Errorf("%s:%d: invalid output_lines", path, lineNo)
			}
			cfg.OutputLines = n
		case "http_timeout_seconds":
			n, convErr := strconv.Atoi(value)
			if convErr != nil || n <= 0 {
				return cfg, fmt.Errorf("%s:%d: invalid http_timeout_seconds", path, lineNo)
			}
			cfg.HTTPTimeoutSecond = n
		}
	}
	if err := scanner.Err(); err != nil {
		return cfg, err
	}

	if token := os.Getenv("TG_BOT_TOKEN"); token != "" {
		cfg.BotToken = token
	}
	if id := os.Getenv("TG_CHAT_ID"); id != "" {
		cfg.ChatID = id
	}
	return cfg, nil
}

func telegramRequest(cfg config, method string, form url.Values, result any) error {
	if cfg.BotToken == "" {
		return errors.New("bot_token is not configured")
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(cfg.HTTPTimeoutSecond)*time.Second)
	defer cancel()

	endpoint := "https://api.telegram.org/bot" + cfg.BotToken + "/" + method
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	if err != nil {
		return err
	}
	var envelope telegramResponse
	if err := json.Unmarshal(body, &envelope); err != nil {
		return fmt.Errorf("unexpected HTTP %d response", resp.StatusCode)
	}
	if !envelope.OK {
		if envelope.Description == "" {
			envelope.Description = resp.Status
		}
		return errors.New(envelope.Description)
	}
	if result != nil && len(envelope.Result) != 0 {
		if err := json.Unmarshal(envelope.Result, result); err != nil {
			return fmt.Errorf("decode API result: %w", err)
		}
	}
	return nil
}

func getChatIDs(cfg config, w io.Writer) error {
	var updates []updatesResult
	if err := telegramRequest(cfg, "getUpdates", url.Values{"timeout": {"0"}}, &updates); err != nil {
		return err
	}

	seen := make(map[string]bool)
	found := make([]foundChat, 0)
	for _, update := range updates {
		messages := []*message{update.Message, update.EditedMessage, update.ChannelPost, update.EditedPost}
		for _, msg := range messages {
			if msg == nil || msg.Chat.ID == 0 {
				continue
			}
			key := fmt.Sprintf("%d/%d", msg.Chat.ID, msg.MessageThreadID)
			if seen[key] {
				continue
			}
			seen[key] = true
			found = append(found, foundChat{
				Type:     msg.Chat.Type,
				Name:     chatName(msg.Chat),
				ChatID:   msg.Chat.ID,
				ThreadID: msg.MessageThreadID,
			})
		}
	}

	if len(found) == 0 {
		fmt.Fprintln(w, "Чаты не найдены.")
		fmt.Fprintln(w, "Отправьте боту сообщение (или сообщение в группе с ботом) и повторите команду.")
		return nil
	}

	fmt.Fprintln(w, "Найденные чаты:")
	for _, item := range found {
		fmt.Fprintln(w)
		fmt.Fprintf(w, "type: %s\n", item.Type)
		fmt.Fprintf(w, "name: %s\n", item.Name)
		fmt.Fprintf(w, "chat_id: %d\n", item.ChatID)
		if item.ThreadID != 0 {
			fmt.Fprintf(w, "thread_id: %d\n", item.ThreadID)
		}
	}
	return nil
}

func chatName(c chat) string {
	if c.Title != "" {
		return c.Title
	}
	name := strings.TrimSpace(strings.TrimSpace(c.FirstName + " " + c.LastName))
	if name != "" {
		return name
	}
	if c.Username != "" {
		return "@" + c.Username
	}
	return "(без названия)"
}

func sendTelegram(cfg config, text string) error {
	if cfg.ChatID == "" {
		return errors.New("chat_id is not configured")
	}
	if len([]rune(text)) > maxTelegramText {
		runes := []rune(text)
		text = "… сообщение сокращено …\n" + string(runes[len(runes)-maxTelegramText:])
	}
	form := url.Values{
		"chat_id":                  {cfg.ChatID},
		"text":                     {text},
		"parse_mode":               {"HTML"},
		"disable_web_page_preview": {"true"},
	}
	if cfg.ThreadID != "" {
		form.Set("message_thread_id", cfg.ThreadID)
	}
	return telegramRequest(cfg, "sendMessage", form, nil)
}

func sendPlainNotification(cfg config, text string) error {
	host, _ := os.Hostname()
	body := fmt.Sprintf("🔔 <b>Уведомление</b>\n\n<b>Сервер:</b> <code>%s</code>\n<b>Сообщение:</b> %s",
		html.EscapeString(host), html.EscapeString(text))
	return sendTelegram(cfg, body)
}

func runCommand(cfg config, args []string) int {
	started := time.Now()
	host, _ := os.Hostname()
	currentUser := "unknown"
	if u, err := user.Current(); err == nil {
		currentUser = u.Username
	}
	commandText := shellQuote(args)

	cmd := exec.Command(args[0], args[1:]...)
	var captured bytes.Buffer
	output := io.MultiWriter(os.Stdout, &captured)
	cmd.Stdout = output
	cmd.Stderr = output
	cmd.Stdin = os.Stdin

	err := cmd.Run()
	exitCode := 0
	if err != nil {
		var exitErr *exec.ExitError
		if errors.As(err, &exitErr) {
			exitCode = exitErr.ExitCode()
		} else {
			fmt.Fprintf(os.Stderr, "tgrun: cannot start command: %v\n", err)
			exitCode = 127
		}
	}

	statusIcon, statusText := "✅", "Команда выполнена"
	if exitCode != 0 {
		statusIcon, statusText = "❌", "Ошибка выполнения команды"
	}
	messageText := fmt.Sprintf(
		"%s <b>%s</b>\n\n<b>Сервер:</b> <code>%s</code>\n<b>Пользователь:</b> <code>%s</code>\n<b>Команда:</b>\n<code>%s</code>\n\n<b>Код возврата:</b> <code>%d</code>\n<b>Время выполнения:</b> <code>%s</code>\n<b>Запущено:</b> <code>%s</code>",
		statusIcon,
		statusText,
		html.EscapeString(host),
		html.EscapeString(currentUser),
		html.EscapeString(commandText),
		exitCode,
		formatDuration(time.Since(started)),
		started.Format("2006-01-02 15:04:05 -0700"),
	)

	includeOutput := cfg.SendOutput == "always" || (cfg.SendOutput == "on-error" && exitCode != 0)
	if includeOutput && cfg.OutputLines > 0 && captured.Len() > 0 {
		tail := tailLines(captured.String(), cfg.OutputLines)
		if len([]rune(tail)) > 2400 {
			runes := []rune(tail)
			tail = "… вывод сокращён …\n" + string(runes[len(runes)-2400:])
		}
		messageText += "\n\n<b>Последние строки вывода:</b>\n<pre>" + html.EscapeString(tail) + "</pre>"
	}

	if notifyErr := sendTelegram(cfg, messageText); notifyErr != nil {
		fmt.Fprintf(os.Stderr, "\ntgrun: command completed, but notification failed: %v\n", notifyErr)
	}
	return exitCode
}

func tailLines(text string, count int) string {
	text = strings.TrimRight(text, "\r\n")
	lines := strings.Split(text, "\n")
	if len(lines) > count {
		lines = lines[len(lines)-count:]
	}
	return strings.Join(lines, "\n")
}

func formatDuration(d time.Duration) string {
	total := int64(d.Round(time.Second) / time.Second)
	return fmt.Sprintf("%02d:%02d:%02d", total/3600, (total%3600)/60, total%60)
}

func shellQuote(args []string) string {
	quoted := make([]string, len(args))
	for i, arg := range args {
		if arg != "" && !strings.ContainsAny(arg, " \t\n'\"\\$&|;<>()*?[]{}!") {
			quoted[i] = arg
		} else {
			quoted[i] = "'" + strings.ReplaceAll(arg, "'", `'\''`) + "'"
		}
	}
	return strings.Join(quoted, " ")
}
