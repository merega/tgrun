package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestShellQuote(t *testing.T) {
	got := shellQuote([]string{"bash", "-lc", "printf '%s\n' \"$HOME\""})
	want := `bash -lc 'printf '\''%s
'\'' "$HOME"'`
	if got != want {
		t.Fatalf("shellQuote() = %q, want %q", got, want)
	}
}

func TestFormatDuration(t *testing.T) {
	got := formatDuration(2*time.Hour + 3*time.Minute + 4*time.Second)
	if got != "02:03:04" {
		t.Fatalf("formatDuration() = %q", got)
	}
}

func TestTailLines(t *testing.T) {
	got := tailLines("one\ntwo\nthree\n", 2)
	if got != "two\nthree" {
		t.Fatalf("tailLines() = %q", got)
	}
}

func TestLoadConfig(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "tgrun.conf")
	body := strings.Join([]string{
		"bot_token='token'",
		"chat_id=-100123",
		"thread_id=15",
		"send_output=always",
		"output_lines=42",
		"http_timeout_seconds=9",
	}, "\n")
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}

	cfg, err := loadConfig(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.BotToken != "token" || cfg.ChatID != "-100123" || cfg.ThreadID != "15" {
		t.Fatalf("unexpected Telegram config: %#v", cfg)
	}
	if cfg.SendOutput != "always" || cfg.OutputLines != 42 || cfg.HTTPTimeoutSecond != 9 {
		t.Fatalf("unexpected output config: %#v", cfg)
	}
}
