#!/usr/bin/env sh
set -eu

PYTHON=${PYTHON:-python3}
"$PYTHON" tools/release.py

if command -v dpkg-deb >/dev/null 2>&1; then
  for package in dist/tgrun_1.1.0_amd64.deb dist/tgrun_1.1.0_arm64.deb; do
    dpkg-deb --info "$package"
    dpkg-deb --contents "$package"
  done
else
  printf '%s\n' 'dpkg-deb not found; packages were built in standard ar/tar format.'
fi

printf '%s\n' 'Verify published files with: (cd dist && sha256sum -c SHA256SUMS)'
