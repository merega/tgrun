module tgrun

go 1.22
